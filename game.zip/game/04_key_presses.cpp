#include <SDL.h>
#include <stdio.h>
#include <string>
#include <SDL_image.h>

const int SPEED = 1;
const int FPS = 240;
const int frameDelay = 1000 / FPS;
SDL_Window* window = NULL;
SDL_Surface* screen = NULL;
SDL_Surface* img = NULL;
SDL_Surface* temp = NULL;

Uint32 frameStart;
int frameTime;

int main(int argc, char* args[]) {
	if(SDL_Init(SDL_INIT_VIDEO) < 0) {
		printf( "SDL could not initialize! SDL Error: %s\n", SDL_GetError() );
		return 0;
	}
	if (!IMG_Init(IMG_INIT_PNG)) {
		printf( "SDL_image could not initialize! SDL_image Error: %s\n", IMG_GetError() );
		return 0;
	}
	window = SDL_CreateWindow("Move", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 1000, 600, SDL_WINDOW_SHOWN);
	screen = SDL_GetWindowSurface(window);

	temp = IMG_Load("char.png");
	if (temp == NULL) {
		printf( "Failed to load PNG image!\n" );
		return 0;
	}
	img = SDL_ConvertSurface(temp, screen->format, 0);
	if (img == NULL) {
		printf( "Failed to create PNG image!\n" );
		return 0;
	}
	SDL_FreeSurface(temp);

	SDL_Rect cast;
	cast.x = 0;
	cast.y = 0;
	cast.h = 60;
	cast.w = 60;

	SDL_Event event;
	bool quit = false;
	bool up = false, down = false, left = false, right = false;

	while(!quit) {
		SDL_FillRect( screen, NULL, SDL_MapRGB( screen->format, 0xFF, 0xFF, 0xFF ) );
		frameStart = SDL_GetTicks();
		if (SDL_PollEvent(&event) != 0) {
			if (event.type == SDL_QUIT) {
				quit = true;
			} else if(event.type == SDL_KEYDOWN) {
				switch (event.key.keysym.sym) {
					case SDLK_w:
						up = true;
						break;
					case SDLK_a:
						left = true;
						break;
					case SDLK_s:
						down = true;
						break;
					case SDLK_d:
						right = true;
						break;
					default:
						break;
				}
			} else if(event.type == SDL_KEYUP) {
				switch (event.key.keysym.sym) {
					case SDLK_w:
						up = false;
						break;
					case SDLK_a:
						left = false;
						break;
					case SDLK_s:
						down = false;
						break;
					case SDLK_d:
						right = false;
						break;
					default:
						break;
				}
			}
		}

		if (up) cast.y -= SPEED;
		if (down) cast.y += SPEED;
		if (left) cast.x -= SPEED;
		if (right) cast.x += SPEED;

		SDL_BlitScaled(img, NULL, screen, &cast);

		frameTime = SDL_GetTicks() - frameStart;
		if(frameDelay > frameTime) {
			SDL_Delay(frameDelay - frameTime);
		}

		SDL_UpdateWindowSurface(window);
	}


	SDL_Quit();
	return 0;
}